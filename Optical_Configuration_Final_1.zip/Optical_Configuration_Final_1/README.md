# LM358-Files
Repo that has the LM358 files for use with LTSpice
